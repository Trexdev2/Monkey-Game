
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var bananaGroup, obstacleGroup
var score
var ground


var survivalTime = 0;

function preload(){
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImg = loadImage("banana.png");
  obstacleImg = loadImage("obstacle.png");
 
}


function setup() {
  monkey = createSprite(100,340,20,50);
  monkey.addAnimation("monkey", monkey_running);
  monkey.scale = 0.12;
  
  
  ground = createSprite(200,350,800,10);
  ground.shapeColor = 'brown';
  ground.velocityX = -4
  
  bananaGroup = new Group();
  obstacleGroup =  new Group();
}


function draw() {
  background('white');
  
  monkey.collide(ground);
  
  if (keyDown("space") && monkey.y > 308.15){
    monkey.velocityY = -12;
  }
  
  monkey.velocityY = monkey.velocityY + 0.5;
  
  if (bananaGroup.isTouching(monkey)){
    bananaGroup.destroyEach();
  }
  
  if (obstacleGroup.isTouching(monkey)){
      //placeholder
  }
  
  
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  
  bananafunc();
  obstaclefunc();

  drawSprites();
  
  stroke("black");
  textSize(20);
  fill("black");
  survivalTime = Math.round(frameCount/40);
  text("Survival Time: "+ survivalTime, 100, 50);
}


function bananafunc(){
  if (World.frameCount%80 === 0){
    banana = createSprite(400,Math.round(random(150,250)),20,20);
    banana.addImage("banana", bananaImg);
    banana.velocityX = -4;
    banana.scale = 0.1;
    banana.lifetime = 200;
    bananaGroup.add(banana);
  }
}


function obstaclefunc(){
  if (World.frameCount%100 === 0){
    obstacle = createSprite(400,313,20,20);
    obstacle.addImage("obstacle", obstacleImg);
    obstacle.velocityX = -5;
    obstacle.scale = 0.17;
    obstacle.lifetime = 200;
    obstacleGroup.add(obstacle);
  }
}